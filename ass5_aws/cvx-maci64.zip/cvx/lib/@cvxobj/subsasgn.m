function x = subsasgn( x, S, y )
error( 'Subscripted assignment not allowed for these objects.' );

% Copyright 2005-2014 CVX Research, Inc.
% See the file LICENSE.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
